package com.atlassian.tutorial.helloworld.api;

public interface MyPluginComponent
{
    String getName();
}